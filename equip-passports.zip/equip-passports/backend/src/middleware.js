import cors from 'cors'
import jwt from 'jsonwebtoken'

export const corsMw = cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
  credentials: false
})

export function authGuard(req, res, next) {
  const header = req.headers.authorization || ''
  console.log("🔐 authGuard header =", header)

  const token = header.startsWith('Bearer ') ? header.slice(7) : null
  if (!token) {
    console.warn("⛔ Нет токена")
    return res.status(401).json({ error: 'No token' })
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev')
    console.log("✅ JWT payload =", payload)
    req.user = payload
    next()
  } catch (err) {
    console.error("⛔ Invalid token:", err.message)
    return res.status(401).json({ error: 'Invalid token' })
  }
}
