// backend/src/departments.js
import { Router } from 'express'
import { PrismaClient } from '@prisma/client'
import { authGuard } from './middleware.js'

const prisma = new PrismaClient()
const router = Router()

// -------------------------------------------------
// Список подразделений
// -------------------------------------------------
router.get('/', authGuard, async (_req, res) => {
  try {
    const list = await prisma.department.findMany({
      orderBy: { id: 'asc' }
    })
    res.json(list)
  } catch (e) {
    res.status(500).json({ error: 'cannot fetch departments', details: String(e) })
  }
})

// -------------------------------------------------
// Создать подразделение (только админ)
// -------------------------------------------------
router.post('/', authGuard, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'forbidden' })
  }
  const { name } = req.body || {}
  if (!name) return res.status(400).json({ error: 'name обязателен' })

  try {
    const dep = await prisma.department.create({ data: { name } })
    res.status(201).json(dep)
  } catch (e) {
    res.status(400).json({ error: 'cannot create department', details: String(e) })
  }
})

// -------------------------------------------------
// Обновить подразделение
// -------------------------------------------------
router.put('/:id', authGuard, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'forbidden' })
  }
  const { name } = req.body || {}
  try {
    const dep = await prisma.department.update({
      where: { id: Number(req.params.id) },
      data: { name }
    })
    res.json(dep)
  } catch (e) {
    res.status(400).json({ error: 'cannot update department', details: String(e) })
  }
})

// -------------------------------------------------
// Удалить подразделение
// -------------------------------------------------
router.delete('/:id', authGuard, async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'forbidden' })
  }
  try {
    await prisma.department.delete({ where: { id: Number(req.params.id) } })
    res.json({ ok: true })
  } catch (e) {
    res.status(400).json({ error: 'cannot delete department', details: String(e) })
  }
})

export default router
