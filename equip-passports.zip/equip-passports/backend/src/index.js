import 'dotenv/config';
import express from 'express';
import morgan from 'morgan';
import http from 'http';
import { corsMw } from './middleware.js';
import users from './users.js';
import equipment from './equipment.js';
import workorders from './workorders.js';
import departments from './departments.js';
import authRoutes from './routes/auth.routes.js';
import { initWs } from './ws.js';
import roleRoutes from "./routes/roles.js";

const app = express();
app.use(express.json());
app.use(corsMw);
app.use(morgan('dev'));

// 📂 раздаём загруженные файлы
app.use("/uploads", express.static("uploads"));

app.get('/api/health', (_req, res) => res.json({ ok: true }));

// роутеры
app.use('/api/auth', authRoutes);
app.use('/api/users', users);
app.use('/api/equipment', equipment);
app.use('/api/workorders', workorders);
app.use('/api/departments', departments);
app.use("/api/roles", roleRoutes);

const port = process.env.PORT || 8080;
const server = http.createServer(app);

// запускаем ws поверх http
initWs(server);

server.listen(port, () => console.log(`API + WS on :${port}`));
