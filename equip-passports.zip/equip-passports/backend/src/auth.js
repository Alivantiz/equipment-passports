import { Router } from 'express'
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'

const prisma = new PrismaClient()
const router = Router()

const JWT_SECRET = process.env.JWT_SECRET || 'dev'

// --- LOGIN ---
router.post('/login', async (req, res) => {
  const { login, password } = req.body || {}
  if (!login || !password) return res.status(400).json({ error: 'login and password required' })

  const user = await prisma.user.findUnique({ where: { login } })
  if (!user) return res.status(401).json({ error: 'bad credentials' })

  const ok = await bcrypt.compare(password, user.passwordHash)
  if (!ok) return res.status(401).json({ error: 'bad credentials' })

  // access и refresh
  const access = jwt.sign({ uid: user.id, login: user.login }, JWT_SECRET, { expiresIn: '15m' })
  const refresh = jwt.sign({ uid: user.id, login: user.login }, JWT_SECRET, { expiresIn: '7d' })

  // сохраняем refresh в БД
  await prisma.refreshToken.create({
    data: { token: refresh, userId: user.id, expiresAt: new Date(Date.now() + 7*24*60*60*1000) }
  })

  return res.json({
    access,
    refresh,
    user: { id: user.id, login: user.login, fio: user.fio, position: user.position }
  })
})

// --- REFRESH ---
router.post('/refresh', async (req, res) => {
  const { refresh } = req.body || {}
  if (!refresh) return res.status(400).json({ error: 'no refresh token' })

  const rt = await prisma.refreshToken.findUnique({ where: { token: refresh }, include: { user: true } })
  if (!rt || rt.expiresAt < new Date()) return res.status(401).json({ error: 'invalid refresh token' })

  try {
    const payload = jwt.verify(refresh, JWT_SECRET)
    const access = jwt.sign({ uid: payload.uid, login: payload.login }, JWT_SECRET, { expiresIn: '15m' })
    return res.json({ access })
  } catch {
    return res.status(401).json({ error: 'invalid refresh token' })
  }
})

// --- LOGOUT ---
router.post('/logout', async (req, res) => {
  const { refresh } = req.body || {}
  if (refresh) await prisma.refreshToken.deleteMany({ where: { token: refresh } })
  res.json({ ok: true })
})

export default router
