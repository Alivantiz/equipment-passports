import { Router } from "express";
import { PrismaClient } from "@prisma/client";
import { authGuard } from "./middleware.js";
import {
  toEnumArea,
  toEnumEquipStatus,
  materializeEquipment,
  materializeWorkOrder,
} from "./enums.js";

const prisma = new PrismaClient();
const router = Router();

// -----------------------------------------------------------------------------
// 📌 Характеристики оборудования
// -----------------------------------------------------------------------------

// Получить все характеристики
router.get("/:id/attributes", authGuard, async (req, res) => {
  try {
    const attrs = await prisma.equipmentAttribute.findMany({
      where: { equipmentId: Number(req.params.id) },
      orderBy: { id: "asc" },
    });
    res.json(attrs);
  } catch (e) {
    res.status(500).json({ error: "Ошибка получения характеристик", details: String(e) });
  }
});

// Добавить характеристику
router.post("/:id/attributes", authGuard, async (req, res) => {
  const { key, value } = req.body || {};
  if (!key) return res.status(400).json({ error: "key обязателен" });

  try {
    const attr = await prisma.equipmentAttribute.create({
      data: {
        equipmentId: Number(req.params.id),
        key,
        value: value || "",
      },
    });
    res.status(201).json(attr);
  } catch (e) {
    res.status(500).json({ error: "Ошибка добавления характеристики", details: String(e) });
  }
});

// Обновить характеристику
router.put("/attributes/:attrId", authGuard, async (req, res) => {
  const { key, value } = req.body || {};
  try {
    const attr = await prisma.equipmentAttribute.update({
      where: { id: Number(req.params.attrId) },
      data: { key, value },
    });
    res.json(attr);
  } catch (e) {
    res.status(400).json({ error: "cannot update attr", details: String(e) });
  }
});

// Удалить характеристику
router.delete("/attributes/:attrId", authGuard, async (req, res) => {
  try {
    await prisma.equipmentAttribute.delete({ where: { id: Number(req.params.attrId) } });
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: "cannot delete attr", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Документы оборудования
// -----------------------------------------------------------------------------
router.get("/:id/documents", authGuard, async (req, res) => {
  try {
    const docs = await prisma.equipmentDocument.findMany({
      where: { equipmentId: Number(req.params.id) },
      orderBy: { createdAt: "desc" },
    });
    res.json(docs);
  } catch (e) {
    res.status(500).json({ error: "Ошибка получения документов", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Заявки по оборудованию
// -----------------------------------------------------------------------------
router.get("/:id/orders", authGuard, async (req, res) => {
  try {
    const orders = await prisma.workOrder.findMany({
      where: { equipmentId: Number(req.params.id) },
      orderBy: { createdAt: "desc" },
      include: { assignedTo: true, equipment: true, attachments: true, comments: true },
    });
    res.json(orders.map(materializeWorkOrder));
  } catch (e) {
    res.status(500).json({ error: "Ошибка получения заявок", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Список оборудования
// -----------------------------------------------------------------------------
router.get("/", authGuard, async (req, res) => {
  const { area, status } = req.query;
  const where = {};
  const areaCode = toEnumArea(area);
  const statusCode = toEnumEquipStatus(status);
  if (area && areaCode) where.area = areaCode;
  if (status && statusCode) where.status = statusCode;

  try {
    const list = await prisma.equipment.findMany({ where, orderBy: { id: "desc" } });
    res.json(list.map(materializeEquipment));
  } catch (e) {
    res.status(500).json({ error: "Ошибка загрузки оборудования", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Создать оборудование
// -----------------------------------------------------------------------------
router.post("/", authGuard, async (req, res) => {
  const { category, position, name, serial, area, status } = req.body || {};
  const areaCode = toEnumArea(area);
  const statusCode = toEnumEquipStatus(status) || "RABOTAET";
  if (!name || !serial || !areaCode) {
    return res.status(400).json({ error: "name, serial, area обязательны" });
  }

  try {
    const item = await prisma.equipment.create({
      data: { category, position, name, serial, area: areaCode, status: statusCode },
    });
    res.status(201).json(materializeEquipment(item));
  } catch (e) {
    res.status(400).json({ error: "unique constraint? check serial", details: String(e) });
  }
});

export default router;
