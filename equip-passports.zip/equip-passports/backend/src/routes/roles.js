import { Router } from "express";
import { PrismaClient } from "@prisma/client";
import { authGuard } from "../middleware.js";

const prisma = new PrismaClient();
const router = Router();

// получить список ролей с правами
router.get("/", authGuard, async (_req, res) => {
  const rows = await prisma.rolePermission.findMany();
  const grouped = {};
  for (const r of rows) {
    if (!grouped[r.role]) grouped[r.role] = [];
    grouped[r.role].push(r.perm);
  }
  res.json(grouped);
});

// обновить права роли
router.put("/:role", authGuard, async (req, res) => {
  const { role } = req.params;
  const { permissions } = req.body;
  if (!Array.isArray(permissions)) {
    return res.status(400).json({ error: "permissions must be array" });
  }

  // сначала очистим старые
  await prisma.rolePermission.deleteMany({ where: { role } });
  // затем добавим новые
  for (const p of permissions) {
    await prisma.rolePermission.create({ data: { role, perm: p } });
  }
  res.json({ ok: true });
});

export default router;
