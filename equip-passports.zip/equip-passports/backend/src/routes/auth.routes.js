import { Router } from 'express'
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'

const prisma = new PrismaClient()
const router = Router()

const JWT_SECRET = process.env.JWT_SECRET || 'dev'

// --- LOGIN ---
router.post('/login', async (req, res) => {
  const { login, password } = req.body || {}
  if (!login || !password) {
    return res.status(400).json({ error: 'login and password required' })
  }

  try {
    const user = await prisma.user.findUnique({ where: { login } })
    if (!user) return res.status(401).json({ error: 'bad credentials' })

    const ok = await bcrypt.compare(password, user.passwordHash)
    if (!ok) return res.status(401).json({ error: 'bad credentials' })

    const access = jwt.sign(
      { uid: user.id, login: user.login, role: user.role },
      JWT_SECRET,
      { expiresIn: '15m' }
    )
    const refresh = jwt.sign(
      { uid: user.id, login: user.login, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    )

    // сохраняем refresh в БД
    try {
      await prisma.refreshToken.create({
        data: {
          token: refresh,
          userId: user.id,
          expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 дней
        }
      })
    } catch (e) {
      console.error('❌ Ошибка при сохранении refresh-токена:', e)
    }

    return res.json({
      access,
      refresh,
      user: {
        id: user.id,
        login: user.login,
        fio: user.fio,
        position: user.position,
        role: user.role
      }
    })
  } catch (err) {
    console.error('❌ Ошибка в login:', err)
    return res.status(500).json({ error: 'internal error' })
  }
})

// --- REFRESH ---
router.post('/refresh', async (req, res) => {
  const { refresh } = req.body || {}
  if (!refresh) return res.status(400).json({ error: 'no refresh token' })

  try {
    const rt = await prisma.refreshToken.findUnique({
      where: { token: refresh },
      include: { user: true }
    })
    if (!rt || rt.expiresAt < new Date()) {
      return res.status(401).json({ error: 'invalid refresh token' })
    }

    jwt.verify(refresh, JWT_SECRET) // если подпись битая → кинет исключение
    const access = jwt.sign(
      { uid: rt.userId, login: rt.user.login, role: rt.user.role },
      JWT_SECRET,
      { expiresIn: '15m' }
    )
    return res.json({ access })
  } catch (err) {
    console.error('❌ Ошибка в refresh:', err)
    return res.status(401).json({ error: 'invalid refresh token' })
  }
})

// --- LOGOUT ---
router.post('/logout', async (req, res) => {
  const { refresh } = req.body || {}
  try {
    if (refresh) {
      await prisma.refreshToken.deleteMany({ where: { token: refresh } })
    }
    return res.json({ ok: true })
  } catch (err) {
    console.error('❌ Ошибка в logout:', err)
    return res.status(500).json({ error: 'internal error' })
  }
})

export default router
