// backend/src/users.js
import { Router } from 'express'
import { PrismaClient } from '@prisma/client'
import { authGuard } from './middleware.js'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()
const router = Router()

// -------------------------------------------------
// Текущий пользователь (профиль)
// -------------------------------------------------
router.get('/me', authGuard, async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user.uid },
    include: { department: true }
  })
  res.json({
    id: user.id,
    login: user.login,
    fio: user.fio,
    position: user.position,
    role: user.role,
    department: user.department
      ? { id: user.department.id, name: user.department.name }
      : null
  })
})

router.put('/me', authGuard, async (req, res) => {
  const { fio, position } = req.body || {}
  const user = await prisma.user.update({
    where: { id: req.user.uid },
    data: { fio, position }
  })
  res.json({
    id: user.id,
    login: user.login,
    fio: user.fio,
    position: user.position
  })
})

// -------------------------------------------------
// Управление пользователями (только админ)
// -------------------------------------------------
router.get('/', authGuard, async (req, res) => {
  if (req.user.role !== 'admin')
    return res.status(403).json({ error: 'forbidden' })
  const list = await prisma.user.findMany({
    include: { department: true },
    orderBy: { id: 'asc' }
  })
  res.json(
    list.map((u) => ({
      id: u.id,
      login: u.login,
      fio: u.fio,
      position: u.position,
      role: u.role,
      department: u.department
        ? { id: u.department.id, name: u.department.name }
        : null
    }))
  )
})

// Создать пользователя (пароль по умолчанию user123)
router.post('/', authGuard, async (req, res) => {
  if (req.user.role !== 'admin')
    return res.status(403).json({ error: 'forbidden' })
  const { login, fio, position, role, departmentId } = req.body || {}
  if (!login) return res.status(400).json({ error: 'login обязателен' })

  try {
    const passwordHash = await bcrypt.hash('user123', 10)
    const user = await prisma.user.create({
      data: { login, passwordHash, fio, position, role, departmentId }
    })
    res.status(201).json(user)
  } catch (e) {
    res.status(400).json({ error: 'cannot create user', details: String(e) })
  }
})

// Обновить данные пользователя
router.put('/:id', authGuard, async (req, res) => {
  if (req.user.role !== 'admin')
    return res.status(403).json({ error: 'forbidden' })
  const { fio, position, role, departmentId } = req.body || {}
  try {
    const user = await prisma.user.update({
      where: { id: Number(req.params.id) },
      data: { fio, position, role, departmentId }
    })
    res.json(user)
  } catch (e) {
    res.status(400).json({ error: 'cannot update user', details: String(e) })
  }
})

// Сброс пароля (новый пароль user123)
router.put('/:id/reset-password', authGuard, async (req, res) => {
  if (req.user.role !== 'admin')
    return res.status(403).json({ error: 'forbidden' })

  try {
    const passwordHash = await bcrypt.hash('user123', 10)
    await prisma.user.update({
      where: { id: Number(req.params.id) },
      data: { passwordHash }
    })
    res.json({ ok: true })
  } catch (e) {
    res.status(400).json({ error: 'cannot reset password', details: String(e) })
  }
})

// Удалить пользователя
router.delete('/:id', authGuard, async (req, res) => {
  if (req.user.role !== 'admin')
    return res.status(403).json({ error: 'forbidden' })
  try {
    await prisma.user.delete({ where: { id: Number(req.params.id) } })
    res.json({ ok: true })
  } catch (e) {
    res.status(400).json({ error: 'cannot delete user', details: String(e) })
  }
})

export default router
