import { Router } from "express";
import { PrismaClient } from "@prisma/client";
import { authGuard } from "./middleware.js";
import {
  toEnumArea,
  toEnumWorkStatus,
  materializeWorkOrder,
} from "./enums.js";
import {
  notifyNewWorkOrder,
  notifyStatusChanged,
  notifyCommentAdded,
  notifyAttachmentAdded,
} from "./ws.js";

import multer from "multer";
import path from "path";
import fs from "fs";

const prisma = new PrismaClient();
const router = Router();

// 📂 каталог для файлов
const uploadDir = "uploads";
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  },
});
const upload = multer({ storage });

async function getCurrentUser(req) {
  if (!req.user?.uid) return null;
  return prisma.user.findUnique({ where: { id: req.user.uid } });
}

// -----------------------------------------------------------------------------
// Список заявок
// -----------------------------------------------------------------------------
router.get("/", authGuard, async (req, res) => {
  const { area, status } = req.query;
  const where = {};
  const areaCode = toEnumArea(area);
  const statusCode = toEnumWorkStatus(status);
  if (area && areaCode) where.area = areaCode;
  if (status && statusCode) where.status = statusCode;

  const list = await prisma.workOrder.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: { equipment: true, assignedTo: true, attachments: true },
  });
  res.json(list.map(materializeWorkOrder));
});

// -----------------------------------------------------------------------------
// Создать заявку
// -----------------------------------------------------------------------------
router.post("/", authGuard, async (req, res) => {
  const { equipmentId, issue, departments } = req.body || {};
  if (!equipmentId || !issue)
    return res.status(400).json({ error: "equipmentId и issue обязательны" });

  const eq = await prisma.equipment.findUnique({
    where: { id: Number(equipmentId) },
  });
  if (!eq) return res.status(400).json({ error: "Оборудование не найдено" });

  const user = await getCurrentUser(req);
  const issuedBy = user?.fio || user?.login || "неизвестно";

  const created = await prisma.workOrder.create({
    data: {
      equipmentId: eq.id,
      area: eq.area,
      objectName: eq.name,
      issue,
      issuedBy,
      status: "NOVAYA",
      assignedTo: {
        connect: (departments || []).map((id) => ({ id })),
      },
    },
    include: { equipment: true, assignedTo: true, attachments: true },
  });

  await prisma.comment.create({
    data: {
      text: `Создана заявка: ${issue}`,
      orderId: created.id,
      authorId: req.user?.uid ?? null,
    },
  });

  notifyNewWorkOrder(created, req.user?.uid ?? null);

  res.status(201).json(materializeWorkOrder(created));
});

// -----------------------------------------------------------------------------
// Получить заявку по ID
// -----------------------------------------------------------------------------
router.get("/:id", authGuard, async (req, res) => {
  const id = Number(req.params.id);
  const item = await prisma.workOrder.findUnique({
    where: { id },
    include: {
      equipment: true,
      assignedTo: true,
      attachments: true,
      comments: {
        include: { author: true },
        orderBy: { createdAt: "asc" },
      },
    },
  });
  if (!item) return res.status(404).json({ error: "not found" });

  if (req.user?.uid) {
    await prisma.unreadWorkOrder.deleteMany({
      where: { userId: req.user.uid, orderId: id },
    });
  }

  res.json(materializeWorkOrder(item));
});

// -----------------------------------------------------------------------------
// Принять в работу
// -----------------------------------------------------------------------------
router.post("/:id/accept", authGuard, async (req, res) => {
  const id = Number(req.params.id);

  const order = await prisma.workOrder.findUnique({
    where: { id },
    include: { assignedTo: true },
  });
  if (!order) return res.status(404).json({ error: "not found" });
  if (order.status !== "NOVAYA")
    return res.status(400).json({ error: "Можно принять только новую заявку" });

  const user = await getCurrentUser(req);
  const acceptedBy = user?.fio || user?.login || "неизвестно";

  const updated = await prisma.workOrder.update({
    where: { id },
    data: {
      status: "V_RABOTE",
      acceptedBy,
      acceptedAt: new Date(),
    },
    include: { equipment: true, assignedTo: true, attachments: true },
  });

  await prisma.comment.create({
    data: {
      text: `Принята в работу пользователем ${acceptedBy}`,
      orderId: id,
      authorId: req.user?.uid ?? null,
    },
  });

  await prisma.unreadWorkOrder.deleteMany({ where: { orderId: id } });

  notifyStatusChanged(updated);

  res.json(materializeWorkOrder(updated));
});

// -----------------------------------------------------------------------------
// Завершить заявку
// -----------------------------------------------------------------------------
router.post("/:id/complete", authGuard, async (req, res) => {
  const id = Number(req.params.id);
  const { note } = req.body || {};

  const order = await prisma.workOrder.findUnique({
    where: { id },
    include: { assignedTo: true },
  });
  if (!order) return res.status(404).json({ error: "not found" });
  if (order.status !== "V_RABOTE")
    return res.status(400).json({ error: "Можно завершить только заявку в работе" });

  const user = await getCurrentUser(req);
  const completedBy = user?.fio || user?.login || "неизвестно";

  const updated = await prisma.workOrder.update({
    where: { id },
    data: {
      status: "ZAVERSHENA",
      completedBy,
      completedAt: new Date(),
      note: note || null,
    },
    include: { equipment: true, assignedTo: true, attachments: true },
  });

  await prisma.comment.create({
    data: {
      text: `Заявка завершена пользователем ${completedBy}${note ? `; Примечание: ${note}` : ""}`,
      orderId: id,
      authorId: req.user?.uid ?? null,
    },
  });

  await prisma.unreadWorkOrder.deleteMany({ where: { orderId: id } });

  notifyStatusChanged(updated);

  res.json(materializeWorkOrder(updated));
});

// -----------------------------------------------------------------------------
// Добавить комментарий
// -----------------------------------------------------------------------------
router.post("/:id/comment", authGuard, async (req, res) => {
  const id = Number(req.params.id);
  const { text } = req.body || {};
  if (!text) return res.status(400).json({ error: "text обязателен" });

  const order = await prisma.workOrder.findUnique({ where: { id } });
  if (!order) return res.status(404).json({ error: "not found" });

  const saved = await prisma.comment.create({
    data: { text, orderId: id, authorId: req.user?.uid ?? null },
    include: { author: true },
  });

  // 🔔 оповещение
  notifyCommentAdded(id, saved);

  res.json(saved);
});

// -----------------------------------------------------------------------------
// Вложения
// -----------------------------------------------------------------------------
router.post("/:id/attachments", authGuard, upload.single("file"), async (req, res) => {
  const id = Number(req.params.id);
  if (!req.file) return res.status(400).json({ error: "Файл обязателен" });

  const saved = await prisma.workOrderAttachment.create({
    data: {
      orderId: id,
      fileName: req.file.originalname,
      fileUrl: `/uploads/${req.file.filename}`,
    },
  });

  // 🔔 оповещение
  notifyAttachmentAdded(id, saved);

  res.json(saved);
});

router.get("/:id/attachments", authGuard, async (req, res) => {
  const id = Number(req.params.id);
  const files = await prisma.workOrderAttachment.findMany({
    where: { orderId: id },
    orderBy: { createdAt: "asc" },
  });
  res.json(files);
});

export default router;
