import { Server } from "socket.io";
import { PrismaClient } from "@prisma/client";
import { materializeWorkOrder } from "./enums.js";

const prisma = new PrismaClient();
let io;

export function initWs(httpServer) {
  io = new Server(httpServer, {
    cors: { origin: "*" },
  });

  io.on("connection", (socket) => {
    console.log("🔌 user connected");

    socket.on("joinAdmin", () => {
      socket.join("admins");
    });

    socket.on("joinDepartment", (depId) => {
      socket.join(`dep_${depId}`);
    });

    socket.on("joinUser", (userId) => {
      socket.join(`user_${userId}`);
    });

    socket.on("markRead", async ({ userId }) => {
      await prisma.unreadWorkOrder.deleteMany({ where: { userId } });
      io.to(socket.id).emit("unreadCount", { count: 0 });
    });
  });
}

/**
 * 🔔 Новая заявка
 */
export async function notifyNewWorkOrder(order, excludeUserId = null) {
  const mat = materializeWorkOrder(order);

  io.to("admins").emit("newWorkOrder", mat);

  const deps = Array.isArray(order.assignedTo) ? order.assignedTo : [];
  for (const dep of deps) {
    const users = await prisma.user.findMany({
      where: {
        departmentId: dep.id,
        id: excludeUserId ? { not: excludeUserId } : undefined,
      },
    });

    for (const u of users) {
      io.to(`user_${u.id}`).emit("newWorkOrder", mat);

      try {
        await prisma.unreadWorkOrder.create({
          data: { userId: u.id, orderId: order.id },
        });
      } catch {
        // ignore duplicate
      }
    }
  }
}

/**
 * 🔔 Изменение статуса
 */
export async function notifyStatusChanged(order, excludeUserId = null) {
  const mat = materializeWorkOrder(order);

  io.to("admins").emit("statusChanged", mat);

  const deps = Array.isArray(order.assignedTo) ? order.assignedTo : [];
  for (const dep of deps) {
    const users = await prisma.user.findMany({
      where: {
        departmentId: dep.id,
        id: excludeUserId ? { not: excludeUserId } : undefined,
      },
    });
    for (const u of users) {
      io.to(`user_${u.id}`).emit("statusChanged", mat);
    }
  }

  if (order.issuedBy) {
    const issuer = await prisma.user.findFirst({
      where: {
        OR: [{ fio: order.issuedBy }, { login: order.issuedBy }],
        id: excludeUserId ? { not: excludeUserId } : undefined,
      },
    });
    if (issuer) {
      io.to(`user_${issuer.id}`).emit("statusChanged", mat);
    }
  }
}

/**
 * 🔔 Новый комментарий
 */
export function notifyCommentAdded(orderId, comment) {
  io.emit("commentAdded", { orderId, comment });
}

/**
 * 🔔 Новое вложение
 */
export function notifyAttachmentAdded(orderId, attachment) {
  io.emit("attachmentAdded", { orderId, attachment });
}
