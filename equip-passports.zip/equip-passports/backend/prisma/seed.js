import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  // 🔹 создаём админа
  const adminLogin = "admin";
  const passwordHash = await bcrypt.hash("admin123", 10);

  const existing = await prisma.user.findUnique({
    where: { login: adminLogin },
  });

  if (!existing) {
    await prisma.user.create({
      data: {
        login: adminLogin,
        passwordHash,
        fio: "Администратор",
        position: "Инженер связи",
        role: "admin",
      },
    });
    console.log("✅ Seed: admin created (login: admin / pass: admin123)");
  } else {
    console.log("ℹ️ Seed: admin already exists");
  }

  // 🔹 создаём подразделения
  await prisma.department.createMany({
    data: [{ name: "АСУТП" }, { name: "СГЭ" }, { name: "СГМ" }],
    skipDuplicates: true,
  });
  console.log("✅ Seed: departments added");

  // 🔹 дефолтные роли и права
  const rolePermissions = [
    // админ
    { role: "admin", perm: "manage_users" },
    { role: "admin", perm: "manage_deps" },
    { role: "admin", perm: "manage_orders" },

    // инженер
    { role: "engineer", perm: "manage_orders" },

    // просмотрщик — пусто
  ];

  for (const rp of rolePermissions) {
    await prisma.rolePermission.upsert({
      where: { role_perm: { role: rp.role, perm: rp.perm } }, // 👈 уникальный индекс
      update: {},
      create: rp,
    });
  }
  console.log("✅ Seed: role permissions added");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
