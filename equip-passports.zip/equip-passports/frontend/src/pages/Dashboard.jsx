import { Card } from 'antd'
export default function Dashboard(){
  return <Card>Дашборд (добавим графики позже)</Card>
}
