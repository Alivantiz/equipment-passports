import { Table } from "antd";

export default function ServiceTable({ equipmentId }) {
  // можно будет подтягивать из таблицы maintenance
  return (
    <Table
      rowKey="id"
      dataSource={[]} // позже заменить API
      pagination={false}
      columns={[
        { title: "Дата", dataIndex: "date" },
        { title: "Вид работ", dataIndex: "type" },
        { title: "Исполнитель", dataIndex: "executor" },
        { title: "Комментарий", dataIndex: "note" }
      ]}
    />
  );
}
