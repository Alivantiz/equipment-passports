import { useEffect, useMemo, useState } from "react";
import {
  Card,
  Table,
  Tag,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Space,
  message,
} from "antd";
import api from "../../api";
import { useSearchParams } from "react-router-dom";
import PassportModal from "./PassportModal.jsx";

const STATUS_COLORS = {
  работает: "green",
  "план ТО": "gold",
  авария: "red",
  "в резерве": "default",
};

const AREAS = ["ГТП", "ЦППР", "АЦ", "ТНС"];

export default function Catalog() {
  const [list, setList] = useState([]);
  const [statusFilter, setStatusFilter] = useState();
  const [open, setOpen] = useState(false);
  const [form] = Form.useForm();
  const [selected, setSelected] = useState(null);

  const [searchParams] = useSearchParams();

  const load = async () => {
    try {
      const { data } = await api.get("/equipment");
      setList(data);
    } catch {
      message.error("Ошибка загрузки оборудования");
    }
  };

  useEffect(() => {
    load();
  }, []);

  const columns = [
    { title: "Оборудование", dataIndex: "name" },
    { title: "Категория", dataIndex: "category" },
    { title: "Позиция", dataIndex: "position" },
    { title: "Серийный", dataIndex: "serial" },
    { title: "Цех", dataIndex: "area" },
    {
      title: "Статус",
      dataIndex: "status",
      render: (s) => <Tag color={STATUS_COLORS[s]}>{s}</Tag>,
    },
    {
      title: "Действия",
      render: (_, rec) => (
        <Button type="link" onClick={() => setSelected(rec)}>
          Паспорт
        </Button>
      ),
    },
  ];

  const filtered = useMemo(
    () => (statusFilter ? list.filter((i) => i.status === statusFilter) : list),
    [list, statusFilter]
  );

  const onCreate = async (v) => {
    try {
      await api.post("/equipment", v);
      message.success("Оборудование добавлено");
      setOpen(false);
      form.resetFields();
      load();
    } catch {
      message.error("Ошибка при добавлении (проверьте уникальность серийного)");
    }
  };

  useEffect(() => {
    const id = searchParams.get("id");
    if (id) {
      const item = list.find((i) => i.id === Number(id));
      if (item) setSelected(item);
    }
  }, [searchParams, list]);

  return (
    <Card
      title="Каталог"
      extra={<Button onClick={() => setOpen(true)}>Добавить</Button>}
    >
      <Space style={{ marginBottom: 12 }}>
        <Select
          placeholder="Фильтр по статусу"
          allowClear
          style={{ width: 220 }}
          value={statusFilter}
          onChange={setStatusFilter}
          options={Object.keys(STATUS_COLORS).map((s) => ({
            label: s,
            value: s,
          }))}
        />
      </Space>
      <Table rowKey="id" columns={columns} dataSource={filtered} pagination={false} />

      <Modal
        title="Новое оборудование"
        open={open}
        onCancel={() => setOpen(false)}
        footer={null}
      >
        <Form layout="vertical" form={form} onFinish={onCreate}>
          <Form.Item name="category" label="Категория" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item name="position" label="Позиция" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item name="name" label="Название" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item name="serial" label="Серийный" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item name="area" label="Цех" rules={[{ required: true }]}>
            <Select options={AREAS.map((a) => ({ label: a, value: a }))} />
          </Form.Item>
          <Form.Item name="status" label="Статус" initialValue="работает">
            <Select
              options={Object.keys(STATUS_COLORS).map((s) => ({ label: s, value: s }))}
            />
          </Form.Item>
          <Button type="primary" htmlType="submit" block>
            Сохранить
          </Button>
        </Form>
      </Modal>

      <PassportModal open={!!selected} equipment={selected} onClose={() => setSelected(null)} />
    </Card>
  );
}
