import { useEffect, useState } from "react";
import {
  Modal,
  Tabs,
  Tag,
  Table,
  Button,
  message,
} from "antd";
import { FileOutlined } from "@ant-design/icons";
import api from "../../api";
import { STATUS_COLORS } from "./constants";

export default function PassportModal({ open, equipment, onClose }) {
  const [attrs, setAttrs] = useState([]);
  const [docs, setDocs] = useState([]);
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    if (!equipment?.id) return;

    const loadAttrs = async () => {
      try {
        const { data } = await api.get(`/equipment/${equipment.id}/attributes`);
        setAttrs(data);
      } catch {
        message.error("Ошибка загрузки характеристик");
      }
    };

    const loadDocs = async () => {
      try {
        const { data } = await api.get(`/equipment/${equipment.id}/documents`);
        setDocs(data);
      } catch {
        message.error("Ошибка загрузки документов");
      }
    };

    const loadOrders = async () => {
      try {
        const { data } = await api.get(`/equipment/${equipment.id}/orders`);
        setOrders(data);
      } catch {
        message.error("Ошибка загрузки заявок");
      }
    };

    loadAttrs();
    loadDocs();
    loadOrders();
  }, [equipment]);

  if (!equipment) return null;

  const mainData = [
    { key: "Категория", value: equipment.category },
    { key: "Серийный №", value: equipment.serial },
    { key: "Позиция", value: equipment.position },
    { key: "Цех", value: equipment.area },
    {
      key: "Статус",
      value: <Tag color={STATUS_COLORS[equipment.status]}>{equipment.status}</Tag>,
    },
    {
      key: "Создано",
      value: new Date(equipment.createdAt).toLocaleString(),
    },
  ];

  return (
    <Modal
      open={open}
      onCancel={onClose}
      footer={null}
      title={`Паспорт: ${equipment.name}`}
      width={900}
    >
      <Tabs
        defaultActiveKey="main"
        items={[
          {
            key: "main",
            label: "Основное",
            children: (
              <Table
                showHeader={false}
                pagination={false}
                rowKey="key"
                dataSource={mainData}
                columns={[
                  { dataIndex: "key", width: 200 },
                  { dataIndex: "value" },
                ]}
              />
            ),
          },
          {
            key: "attrs",
            label: "Характеристики",
            children: (
              <Table
                rowKey="id"
                dataSource={attrs}
                pagination={false}
                columns={[
                  { title: "Ключ", dataIndex: "key" },
                  { title: "Значение", dataIndex: "value" },
                ]}
              />
            ),
          },
          {
            key: "docs",
            label: "Документы",
            children: (
              <Table
                rowKey="id"
                dataSource={docs}
                pagination={false}
                columns={[
                  { title: "Название", dataIndex: "name" },
                  {
                    title: "Файл",
                    dataIndex: "url",
                    render: (url) => (
                      <Button
                        type="link"
                        href={url}
                        target="_blank"
                        icon={<FileOutlined />}
                      >
                        Скачать
                      </Button>
                    ),
                  },
                ]}
              />
            ),
          },
          {
            key: "orders",
            label: "Заявки",
            children: (
              <Table
                rowKey="id"
                dataSource={orders}
                pagination={false}
                columns={[
                  { title: "№", dataIndex: "id", width: 70 },
                  { title: "Неисправность", dataIndex: "issue" },
                  {
                    title: "Статус",
                    dataIndex: "status",
                    render: (s) => <Tag color={STATUS_COLORS[s]}>{s}</Tag>,
                  },
                  {
                    title: "Создана",
                    dataIndex: "createdAt",
                    render: (d) => new Date(d).toLocaleString(),
                  },
                ]}
              />
            ),
          },
          {
            key: "repairs",
            label: "ТО/ремонты",
            children: <div>🔧 Здесь можно вывести историю ТО и ремонтов</div>,
          },
        ]}
      />
    </Modal>
  );
}
