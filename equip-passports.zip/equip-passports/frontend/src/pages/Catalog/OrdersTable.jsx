import { Table, Tag } from "antd";
import { useEffect, useState } from "react";
import api from "../../api";
import { STATUS_COLORS } from "./constants";

export default function OrdersTable({ equipmentId }) {
  const [orders, setOrders] = useState([]);

  const load = async () => {
    try {
      const { data } = await api.get(`/workorders?equipmentId=${equipmentId}`);
      setOrders(data);
    } catch {
      message.error("Ошибка загрузки заявок");
    }
  };

  useEffect(() => {
    if (equipmentId) load();
  }, [equipmentId]);

  return (
    <Table
      rowKey="id"
      dataSource={orders}
      pagination={false}
      columns={[
        { title: "№", dataIndex: "id", width: 80 },
        { title: "Неисправность", dataIndex: "issue" },
        { title: "Дата", dataIndex: "createdAt", render: (d) => new Date(d).toLocaleString() },
        { title: "Статус", dataIndex: "status", render: (s) => <Tag color={STATUS_COLORS[s]}>{s}</Tag> }
      ]}
    />
  );
}
