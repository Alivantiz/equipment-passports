import { Modal, Form, Input, Select, Button, message } from "antd";
import { STATUS_COLORS, AREAS } from "./constants";
import api from "../../api";

export default function EquipmentForm({ open, onClose, reload }) {
  const [form] = Form.useForm();

  const onCreate = async (v) => {
    try {
      await api.post("/equipment", v);
      message.success("Оборудование добавлено");
      onClose();
      form.resetFields();
      reload();
    } catch {
      message.error("Ошибка при добавлении (проверьте уникальность серийного)");
    }
  };

  return (
    <Modal title="Новое оборудование" open={open} onCancel={onClose} footer={null}>
      <Form layout="vertical" form={form} onFinish={onCreate}>
        <Form.Item name="category" label="Категория" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
        <Form.Item name="position" label="Позиция" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
        <Form.Item name="name" label="Название" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
        <Form.Item name="serial" label="Серийный" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
        <Form.Item name="area" label="Цех" rules={[{ required: true }]}>
          <Select options={AREAS.map((a) => ({ label: a, value: a }))} />
        </Form.Item>
        <Form.Item name="status" label="Статус" initialValue="работает">
          <Select options={Object.keys(STATUS_COLORS).map((s) => ({ label: s, value: s }))} />
        </Form.Item>
        <Button type="primary" htmlType="submit" block>
          Сохранить
        </Button>
      </Form>
    </Modal>
  );
}
