import { Card, Table, Tabs, Button, Tag, Checkbox, Space } from "antd";
import { useState, useMemo, useEffect } from "react";
import { Link } from "react-router-dom"; // 👈 добавили
import { useOrders } from "./hooks";
import { STATUS_COLORS } from "./constants";
import CreateOrderModal from "./CreateOrderModal";
import OrderDetailModal from "./OrderDetailModal";

export default function Workorders() {
  const [allOrders] = useOrders();
  const [filter, setFilter] = useState("all");
  const [createOpen, setCreateOpen] = useState(false);
  const [current, setCurrent] = useState(null);

  // --- состояние чекбокса берём из localStorage ---
  const [showCompleted, setShowCompleted] = useState(() => {
    const saved = localStorage.getItem("showCompleted");
    return saved !== null ? JSON.parse(saved) : true; // по умолчанию true
  });

  // --- сохраняем в localStorage при изменении ---
  useEffect(() => {
    localStorage.setItem("showCompleted", JSON.stringify(showCompleted));
  }, [showCompleted]);

  // --- подсчёт заявок ---
  const counts = useMemo(() => {
    const c = { all: allOrders.length, новая: 0, "в работе": 0, завершена: 0 };
    allOrders.forEach((o) => {
      c[o.status] = (c[o.status] || 0) + 1;
    });
    return c;
  }, [allOrders]);

  // --- фильтрация ---
  const orders = useMemo(() => {
    let list = allOrders;
    if (filter !== "all") {
      list = list.filter((o) => o.status === filter);
    }
    if (!showCompleted) {
      list = list.filter((o) => o.status !== "завершена");
    }
    return list;
  }, [allOrders, filter, showCompleted]);

  // --- колонки ---
  const columns = [
    { title: "№", dataIndex: "id", width: 80 },
    {
      title: "Объект",
      dataIndex: "objectName",
      render: (_, rec) => (
        <Link to={`/catalog?id=${rec.equipmentId}`} target="_blank">
          {rec.objectName}
        </Link>
      ),
    },
    { title: "Неисправность", dataIndex: "issue" },
    { title: "Цех", dataIndex: "area", width: 110 },
    { title: "Выдал", dataIndex: "issuedBy", width: 160 },
    {
      title: "Дата создания",
      dataIndex: "createdAt",
      width: 180,
      render: (d) => new Date(d).toLocaleString(),
    },
    {
      title: "Статус",
      dataIndex: "status",
      width: 130,
      render: (s) => <Tag color={STATUS_COLORS[s]}>{s}</Tag>,
    },
  ];

  return (
    <Card
      title="Заявки"
      extra={<Button type="primary" onClick={() => setCreateOpen(true)}>Создать</Button>}
    >
      <Tabs
        activeKey={filter}
        onChange={setFilter}
        items={[
          { key: "all", label: `Все (${counts.all})` },
          { key: "новая", label: `Новая (${counts["новая"] || 0})` },
          { key: "в работе", label: `В работе (${counts["в работе"] || 0})` },
          { key: "завершена", label: `Завершена (${counts["завершена"] || 0})` },
        ]}
      />

      {filter === "all" && (
        <Space style={{ marginBottom: 12 }}>
          <Checkbox
            checked={showCompleted}
            onChange={(e) => setShowCompleted(e.target.checked)}
          >
            Показывать завершённые
          </Checkbox>
        </Space>
      )}

      <Table
        rowKey="id"
        columns={columns}
        dataSource={orders}
        pagination={{ pageSize: 10 }}
        onRow={(rec) => ({
          onClick: () => setCurrent(rec.id),
          style: { cursor: "pointer" },
        })}
      />

      <CreateOrderModal open={createOpen} onClose={() => setCreateOpen(false)} />
      <OrderDetailModal orderId={current} onClose={() => setCurrent(null)} />
    </Card>
  );
}
