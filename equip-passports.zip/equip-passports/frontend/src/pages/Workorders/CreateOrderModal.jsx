import { Modal, Form, Input, Select, Button, message, Tag } from "antd";
import { useState, useEffect } from "react";
import api from "../../api";
import { AREAS } from "./constants";

export default function CreateOrderModal({ open, onClose }) {
  const [form] = Form.useForm();
  const [area, setArea] = useState();
  const [equipOptions, setEquipOptions] = useState([]);
  const [departments, setDepartments] = useState([]); // список из API
  const [selectedDeps, setSelectedDeps] = useState([]); // выбранные ID

  // загрузка списка подразделений при открытии
  useEffect(() => {
    if (!open) return;
    api.get("/departments")
      .then(({ data }) => setDepartments(data))
      .catch(() => message.error("Ошибка загрузки подразделений"));
  }, [open]);

  // загрузка оборудования по цеху
  useEffect(() => {
    if (!area) return setEquipOptions([]);
    api.get(`/equipment?area=${encodeURIComponent(area)}`)
      .then(({ data }) =>
        setEquipOptions(
          data.map((e) => ({
            label: `${e.name} (${e.serial})`,
            value: e.id,
          }))
        )
      )
      .catch(() => message.error("Ошибка загрузки оборудования"));
  }, [area]);

  const onCreate = async (v) => {
    try {
      await api.post("/workorders", {
        equipmentId: v.equipmentId,
        issue: v.issue,
        departments: selectedDeps, // 👈 отправляем выбранные подразделения
      });
      message.success("Заявка создана");
      form.resetFields();
      setArea(undefined);
      setSelectedDeps([]);
      onClose();
    } catch {
      message.error("Не удалось создать заявку");
    }
  };

  return (
    <Modal open={open} title="Новая заявка" onCancel={onClose} footer={null}>
      <Form layout="vertical" form={form} onFinish={onCreate}>
        <Form.Item name="area" label="Цех" rules={[{ required: true }]}>
          <Select
            options={AREAS.map((a) => ({ label: a, value: a }))}
            onChange={setArea}
          />
        </Form.Item>

        <Form.Item
          name="equipmentId"
          label="Оборудование"
          rules={[{ required: true }]}
        >
          <Select
            options={equipOptions}
            disabled={!area}
            showSearch
            optionFilterProp="label"
          />
        </Form.Item>

        <Form.Item name="issue" label="Неисправность" rules={[{ required: true }]}>
          <Input.TextArea rows={3} />
        </Form.Item>

        <Form.Item label="Назначить подразделения">
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {departments.map((dep) => (
              <Tag.CheckableTag
                key={dep.id}
                checked={selectedDeps.includes(dep.id)}
                onChange={(checked) => {
                  setSelectedDeps((prev) =>
                    checked
                      ? [...prev, dep.id]
                      : prev.filter((id) => id !== dep.id)
                  );
                }}
              >
                {dep.name}
              </Tag.CheckableTag>
            ))}
          </div>
        </Form.Item>

        <Button type="primary" htmlType="submit" block>
          Сохранить
        </Button>
      </Form>
    </Modal>
  );
}
