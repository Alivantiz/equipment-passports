import { useEffect, useState } from "react";
import api from "../../api";
import { message } from "antd";

export function useOrderDetail(orderId) {
  const [order, setOrder] = useState(null);

  const loadOrder = async () => {
    if (!orderId) return;
    try {
      const { data } = await api.get(`/workorders/${orderId}`);
      setOrder(data);
    } catch {
      message.error("Ошибка загрузки заявки");
    }
  };

  useEffect(() => {
    loadOrder();
  }, [orderId]);

  return [order, loadOrder];
}
