import {
  Modal,
  Button,
  Tag,
  Form,
  Input,
  Space,
  message,
  Upload,
  List,
  Timeline,
} from "antd";
import { UploadOutlined, FileOutlined } from "@ant-design/icons";
import api from "../../api";
import { STATUS_COLORS } from "./constants";
import { useEffect, useState } from "react";
import { io } from "socket.io-client";

export default function OrderDetailModal({ orderId, onClose }) {
  const [form] = Form.useForm();
  const [uploading, setUploading] = useState(false);
  const [order, setOrder] = useState(null);
  const [commentText, setCommentText] = useState("");

  // загрузка деталей с API
  const loadOrder = async () => {
    if (!orderId) return;
    try {
      const { data } = await api.get(`/workorders/${orderId}`);
      setOrder(data);
    } catch {
      message.error("Ошибка загрузки заявки");
    }
  };

  // начальная загрузка + подписка на сокет
  useEffect(() => {
    loadOrder();

    if (!orderId) return;

    const base = (import.meta.env.VITE_API_URL || "http://localhost:8080/api").replace(
      /\/api\/?$/,
      ""
    );
    const socket = io(base, { transports: ["websocket"] });

    socket.on("commentAdded", (payload) => {
      if (payload.orderId === orderId) {
        setOrder((prev) => ({
          ...prev,
          comments: [...(prev?.comments || []), payload.comment],
        }));
      }
    });

    socket.on("attachmentAdded", (payload) => {
      if (payload.orderId === orderId) {
        setOrder((prev) => ({
          ...prev,
          attachments: [...(prev?.attachments || []), payload.attachment],
        }));
      }
    });

    return () => socket.disconnect();
  }, [orderId]);

  if (!orderId || !order) return null;

  const acceptOrder = async () => {
    try {
      await api.post(`/workorders/${order.id}/accept`);
      message.success("Заявка принята");
      onClose();
    } catch {
      message.error("Не удалось принять заявку");
    }
  };

  const completeOrder = async (v) => {
    try {
      await api.post(`/workorders/${order.id}/complete`, {
        note: v.note || undefined,
      });
      message.success("Заявка завершена");
      onClose();
    } catch {
      message.error("Не удалось завершить заявку");
    }
  };

  const addComment = async () => {
    if (!commentText.trim()) return;
    try {
      await api.post(`/workorders/${order.id}/comment`, { text: commentText });
      setCommentText(""); // комментарий придёт через сокет
    } catch {
      message.error("Не удалось добавить комментарий");
    }
  };

  return (
    <Modal
      open={!!orderId}
      onCancel={onClose}
      footer={null}
      title={`Заявка №${order.id}`}
      width={720}
    >
      <Space direction="vertical" style={{ width: "100%" }}>
        {/* 👇 Объект теперь кликабелен */}
        <div>
          <b>Объект:</b>{" "}
          <a href={`/catalog?id=${order.equipmentId}`} target="_blank" rel="noreferrer">
            {order.objectName}
          </a>
        </div>

        <div><b>Цех:</b> {order.area}</div>
        <div><b>Неисправность:</b> {order.issue}</div>
        <div><b>Выдал:</b> {order.issuedBy}</div>
        <div>
          <b>Статус:</b>{" "}
          <Tag color={STATUS_COLORS[order.status]}>{order.status}</Tag>
        </div>

        {order.acceptedBy && (
          <div>
            <b>Принял:</b> {order.acceptedBy}{" "}
            {order.acceptedAt && `(${new Date(order.acceptedAt).toLocaleString()})`}
          </div>
        )}

        {order.completedBy && (
          <div>
            <b>Выполнил:</b> {order.completedBy}{" "}
            {order.completedAt && `(${new Date(order.completedAt).toLocaleString()})`}
          </div>
        )}

        {order.note && <div><b>Примечание:</b> {order.note}</div>}

        {/* 📂 вложения */}
        {order.attachments?.length > 0 && (
          <div>
            <b>Вложения:</b>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 12, marginTop: 8 }}>
              {order.attachments.map((f) => {
                const isImage = /\.(jpg|jpeg|png|gif)$/i.test(f.fileName);

                return isImage ? (
                  <div key={f.id} style={{ width: 120, textAlign: "center" }}>
                    <img
                      src={f.fileUrl}
                      alt={f.fileName}
                      style={{
                        width: "100%",
                        height: 100,
                        objectFit: "cover",
                        borderRadius: 4,
                        border: "1px solid #ddd",
                        cursor: "pointer",
                      }}
                      onClick={() => window.open(f.fileUrl, "_blank")}
                    />
                    <div style={{ fontSize: 12, marginTop: 4 }}>{f.fileName}</div>
                  </div>
                ) : (
                  <div
                    key={f.id}
                    style={{
                      width: 120,
                      textAlign: "center",
                      padding: 8,
                      border: "1px solid #ddd",
                      borderRadius: 4,
                      cursor: "pointer",
                    }}
                    onClick={() => window.open(f.fileUrl, "_blank")}
                  >
                    <FileOutlined style={{ fontSize: 24, color: "#555" }} />
                    <div style={{ fontSize: 12, marginTop: 4 }}>{f.fileName}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 💬 комментарии */}
        {order.comments?.length > 0 && (
          <div>
            <b>Комментарии:</b>
            <List
              size="small"
              bordered
              dataSource={order.comments.filter(
                (c) =>
                  !c.text.startsWith("Создана заявка") &&
                  !c.text.startsWith("Принята в работу") &&
                  !c.text.startsWith("Завершена")
              )}
              renderItem={(c) => (
                <List.Item>
                  <div>
                    <b>{c.author?.fio || c.author?.login || "неизвестно"}</b>: {c.text}
                    <br />
                    <small>{new Date(c.createdAt).toLocaleString()}</small>
                  </div>
                </List.Item>
              )}
            />
          </div>
        )}

        {/* 📜 история статусов */}
        {order.comments?.length > 0 && (
          <div>
            <b>История:</b>
            <Timeline style={{ marginTop: 8 }}>
              {order.comments
                .filter(
                  (c) =>
                    c.text.startsWith("Создана заявка") ||
                    c.text.startsWith("Принята в работу") ||
                    c.text.startsWith("Завершена")
                )
                .map((c) => {
                  let color = "gray";
                  let dot = null;

                  if (c.text.startsWith("Создана")) {
                    color = "gold";
                    dot = <Tag color="gold">🟡</Tag>;
                  }
                  if (c.text.startsWith("Принята")) {
                    color = "blue";
                    dot = <Tag color="blue">🔵</Tag>;
                  }
                  if (c.text.startsWith("Завершена")) {
                    color = "green";
                    dot = <Tag color="green">🟢</Tag>;
                  }

                  return (
                    <Timeline.Item key={c.id} color={color} dot={dot}>
                      {c.text} <br />
                      <small>{new Date(c.createdAt).toLocaleString()}</small>
                    </Timeline.Item>
                  );
                })}
            </Timeline>
          </div>
        )}
      </Space>

      {/* Кнопка принять */}
      {order.status === "новая" && (
        <Button type="primary" onClick={acceptOrder} style={{ marginTop: 12 }}>
          Принять в работу
        </Button>
      )}

      {/* Форма завершения */}
      {order.status === "в работе" && (
        <Form layout="vertical" form={form} onFinish={completeOrder}>
          <Form.Item name="note" label="Примечание">
            <Input.TextArea rows={2} />
          </Form.Item>

          <Form.Item label="Фото/документы">
            <Upload
              action={`/api/workorders/${order.id}/attachments`}
              multiple
              listType="picture"
              showUploadList={{ showRemoveIcon: false }}
              onChange={({ file }) => {
                if (file.status === "uploading") setUploading(true);
                if (file.status === "done") {
                  setUploading(false);
                  message.success(`${file.name} загружен`);
                  loadOrder();
                }
                if (file.status === "error") {
                  setUploading(false);
                  message.error(`${file.name} не удалось загрузить`);
                }
              }}
            >
              <Button icon={<UploadOutlined />}>Прикрепить</Button>
            </Upload>
          </Form.Item>

          <Button type="primary" htmlType="submit" loading={uploading}>
            Завершить
          </Button>
        </Form>
      )}

      {/* Добавление комментария */}
      <Space style={{ marginTop: 16, width: "100%" }}>
        <Input.TextArea
          value={commentText}
          onChange={(e) => setCommentText(e.target.value)}
          rows={2}
          placeholder="Напишите комментарий..."
        />
        <Button type="primary" onClick={addComment}>
          Отправить
        </Button>
      </Space>
    </Modal>
  );
}
