export const STATUS_COLORS = {
  новая: "gold",
  "в работе": "blue",
  завершена: "green",
};

export const AREAS = ["ГТП", "ЦППР", "АЦ", "ТНС"];
