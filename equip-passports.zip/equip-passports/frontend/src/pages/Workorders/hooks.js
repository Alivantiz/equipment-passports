import { useEffect, useState } from "react";
import { io } from "socket.io-client";
import api from "../../api";
import { message } from "antd";

export function useOrders() {
  const [orders, setOrders] = useState([]);

  // начальная загрузка
  useEffect(() => {
    api.get("/workorders")
      .then(({ data }) => setOrders(data))
      .catch(() => message.error("Ошибка загрузки заявок"));
  }, []);

  // сокеты
  useEffect(() => {
    const base = (import.meta.env.VITE_API_URL || "http://localhost:8080/api").replace(/\/api\/?$/, "");
    const socket = io(base, { transports: ["websocket"] });

    api.get("/users/me").then(({ data: user }) => {
      if (user.role === "admin") socket.emit("joinAdmin");
      if (user.departmentId) socket.emit("joinDepartment", user.departmentId);
    });

    socket.on("newWorkOrder", (order) => {
      message.info(`🔔 Новая заявка: ${order.objectName}`);
      setOrders((prev) => [...prev, order]);
    });

    socket.on("statusChanged", (order) => {
      setOrders((prev) =>
        prev.map((o) => (o.id === order.id ? { ...o, status: order.status } : o))
      );
    });

    return () => socket.disconnect();
  }, []);

  return [orders, setOrders];
}
