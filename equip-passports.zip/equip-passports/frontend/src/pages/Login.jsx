import { Card, Form, Input, Button, message } from "antd"
import api from "../api"
import { useNavigate } from "react-router-dom"

export default function Login({ onLogin }) {
  const nav = useNavigate()

  const onFinish = async (v) => {
    try {
      const { data } = await api.post("/auth/login", v)
      localStorage.setItem("access", data.access)
      localStorage.setItem("refresh", data.refresh)
      localStorage.setItem("user", JSON.stringify(data.user))
      if (onLogin) onLogin()
      nav("/")
    } catch {
      message.error("Неверный логин или пароль")
    }
  }

  return (
    <div style={{ display: "grid", placeItems: "center", height: "100vh" }}>
      <Card title="Вход" style={{ width: 360 }}>
        <Form layout="vertical" onFinish={onFinish}>
          <Form.Item label="Логин" name="login" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item label="Пароль" name="password" rules={[{ required: true }]}>
            <Input.Password />
          </Form.Item>
          <Button type="primary" htmlType="submit" block>
            Войти
          </Button>
        </Form>
      </Card>
    </div>
  )
}
