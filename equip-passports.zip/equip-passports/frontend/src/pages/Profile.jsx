import { Card, Form, Input, Button, message } from 'antd'
import api from '../api'
import { useEffect, useState } from 'react'

export default function Profile() {
  const [form] = Form.useForm()
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    (async () => {
      const { data } = await api.get('/users/me')
      form.setFieldsValue(data)
    })()
  }, [])

  const onSave = async (v) => {
    setLoading(true)
    try {
      await api.put('/users/me', v)
      message.success('Профиль сохранён')
    } finally { setLoading(false) }
  }

  return (
    <Card title="Профиль">
      <Form layout="vertical" form={form} onFinish={onSave}>
        <Form.Item label="ФИО" name="fio"><Input/></Form.Item>
        <Form.Item label="Должность" name="position"><Input/></Form.Item>
        <Button type="primary" htmlType="submit" loading={loading}>Сохранить</Button>
      </Form>
    </Card>
  )
}
