import { Card, Tabs } from "antd";
import { useState, useEffect } from "react";
import api from "../../api";
import UsersTab from "./UsersTab";
import DepartmentsTab from "./DepartmentsTab";
import RolesTab from "./RolesTab";

export default function Settings() {
  const [tab, setTab] = useState("users");
  const [deps, setDeps] = useState([]);

  const loadDeps = async () => {
    try {
      const { data } = await api.get("/departments");
      setDeps(data);
    } catch {
      console.error("Ошибка загрузки подразделений");
    }
  };

  useEffect(() => {
    loadDeps();
  }, []);

  return (
    <Card title="Настройки">
      <Tabs
        activeKey={tab}
        onChange={setTab}
        items={[
          { key: "users", label: "Пользователи", children: <UsersTab deps={deps} reloadDeps={loadDeps} /> },
          { key: "departments", label: "Подразделения", children: <DepartmentsTab deps={deps} reloadDeps={loadDeps} /> },
          { key: "roles", label: "Роли и права", children: <RolesTab /> },
        ]}
      />
    </Card>
  );
}
