import { useEffect, useState } from "react";
import { Table, Button, Modal, Form, Input, Select, message, Popconfirm, Space } from "antd";
import api from "../../api";

export default function UsersTab({ deps, reloadDeps }) {
  const [users, setUsers] = useState([]);
  const [userOpen, setUserOpen] = useState(false);
  const [userForm] = Form.useForm();

  const loadUsers = async () => {
    try {
      const { data } = await api.get("/users");
      setUsers(data);
    } catch {
      message.error("Ошибка загрузки пользователей");
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const createUser = async (v) => {
    try {
      await api.post("/users", { ...v, passwordHash: v.password || "user123" });
      message.success("Пользователь добавлен");
      setUserOpen(false);
      userForm.resetFields();
      loadUsers();
      reloadDeps();
    } catch {
      message.error("Ошибка при добавлении пользователя");
    }
  };

  const resetPassword = async (id) => {
    try {
      await api.put(`/users/${id}/reset-password`);
      message.success("Пароль сброшен (новый: user123)");
    } catch {
      message.error("Не удалось сбросить пароль");
    }
  };

  return (
    <>
      <Button type="primary" onClick={() => setUserOpen(true)} style={{ marginBottom: 12 }}>
        Добавить пользователя
      </Button>
      <Table
        rowKey="id"
        dataSource={users}
        pagination={false}
        columns={[
          { title: "Логин", dataIndex: "login" },
          { title: "ФИО", dataIndex: "fio" },
          { title: "Должность", dataIndex: "position" },
          { title: "Роль", dataIndex: "role" },
          { title: "Подразделение", dataIndex: ["department", "name"] },
          {
            title: "Действия",
            render: (_, rec) => (
              <Space>
                <Popconfirm
                  title="Сбросить пароль?"
                  onConfirm={() => resetPassword(rec.id)}
                >
                  <Button size="small">Сброс</Button>
                </Popconfirm>
              </Space>
            ),
          },
        ]}
      />

      <Modal
        title="Новый пользователь"
        open={userOpen}
        onCancel={() => setUserOpen(false)}
        footer={null}
      >
        <Form layout="vertical" form={userForm} onFinish={createUser}>
          <Form.Item name="login" label="Логин" rules={[{ required: true }]}><Input /></Form.Item>
          <Form.Item name="fio" label="ФИО"><Input /></Form.Item>
          <Form.Item name="position" label="Должность"><Input /></Form.Item>
          <Form.Item name="role" label="Роль" initialValue="engineer">
            <Select
              options={[
                { value: "admin", label: "Админ" },
                { value: "engineer", label: "Инженер" },
                { value: "viewer", label: "Просмотр" },
              ]}
            />
          </Form.Item>
          <Form.Item name="departmentId" label="Подразделение">
            <Select placeholder="Выберите подразделение" options={deps.map(d => ({ value: d.id, label: d.name }))} />
          </Form.Item>
          <Button type="primary" htmlType="submit" block>Сохранить</Button>
        </Form>
      </Modal>
    </>
  );
}
