import { useState } from "react";
import { Table, Button, Modal, Form, Input, message, Space, Tooltip, Popconfirm } from "antd";
import api from "../../api";

export default function DepartmentsTab({ deps, reloadDeps }) {
  const [depOpen, setDepOpen] = useState(false);
  const [depForm] = Form.useForm();
  const [depDetail, setDepDetail] = useState(null);
  const [renameForm] = Form.useForm();
  const [depUsers, setDepUsers] = useState([]);

  const createDep = async (v) => {
    try {
      await api.post("/departments", v);
      message.success("Подразделение добавлено");
      setDepOpen(false);
      depForm.resetFields();
      reloadDeps();
    } catch {
      message.error("Ошибка при добавлении подразделения");
    }
  };

  const openDepDetail = async (dep) => {
    setDepDetail(dep);
    renameForm.setFieldsValue({ name: dep.name });
    try {
      const { data } = await api.get("/users");
      const usersInDep = data.filter((u) => u.department?.id === dep.id);
      setDepUsers(usersInDep);
    } catch {
      message.error("Ошибка загрузки пользователей");
    }
  };

  const renameDep = async (v) => {
    try {
      await api.put(`/departments/${depDetail.id}`, v);
      message.success("Название обновлено");
      setDepDetail(null);
      reloadDeps();
    } catch {
      message.error("Ошибка при обновлении");
    }
  };

  const deleteDep = async () => {
    try {
      await api.delete(`/departments/${depDetail.id}`);
      message.success("Подразделение удалено");
      setDepDetail(null);
      reloadDeps();
    } catch {
      message.error("Ошибка при удалении");
    }
  };

  return (
    <>
      <Button type="primary" onClick={() => setDepOpen(true)} style={{ marginBottom: 12 }}>
        Добавить подразделение
      </Button>
      <Table
        rowKey="id"
        dataSource={deps}
        pagination={false}
        columns={[{ title: "Название", dataIndex: "name" }]}
        onRow={(dep) => ({
          onClick: () => openDepDetail(dep),
          style: { cursor: "pointer" },
        })}
      />

      <Modal title="Новое подразделение" open={depOpen} onCancel={() => setDepOpen(false)} footer={null}>
        <Form layout="vertical" form={depForm} onFinish={createDep}>
          <Form.Item name="name" label="Название" rules={[{ required: true }]}><Input /></Form.Item>
          <Button type="primary" htmlType="submit" block>Сохранить</Button>
        </Form>
      </Modal>

      <Modal title={`Подразделение: ${depDetail?.name}`} open={!!depDetail} onCancel={() => setDepDetail(null)} footer={null}>
        <Form layout="vertical" form={renameForm} onFinish={renameDep} initialValues={{ name: depDetail?.name }}>
          <Form.Item name="name" label="Название" rules={[{ required: true }]}><Input /></Form.Item>
          <Space style={{ display: "flex", justifyContent: "space-between" }}>
            <Button type="primary" htmlType="submit">Сохранить</Button>
            <Tooltip title={depUsers.length > 0 ? "Нельзя удалить подразделение с пользователями" : ""}>
              <Popconfirm title="Удалить подразделение?" okText="Да" cancelText="Нет" onConfirm={deleteDep} disabled={depUsers.length > 0}>
                <Button danger disabled={depUsers.length > 0}>Удалить</Button>
              </Popconfirm>
            </Tooltip>
          </Space>
        </Form>
        <Table
          rowKey="id"
          dataSource={depUsers}
          pagination={false}
          style={{ marginTop: 16 }}
          columns={[
            { title: "Логин", dataIndex: "login" },
            { title: "ФИО", dataIndex: "fio" },
            { title: "Должность", dataIndex: "position" },
            { title: "Роль", dataIndex: "role" },
          ]}
        />
      </Modal>
    </>
  );
}
