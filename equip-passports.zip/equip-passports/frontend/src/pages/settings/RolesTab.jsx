import { useEffect, useState } from "react";
import { Table, Checkbox, Space, message } from "antd";
import api from "../../api";

export default function RolesTab() {
  const [roles, setRoles] = useState([]);

  const allPermissions = [
    { key: "manage_users", label: "Управление пользователями" },
    { key: "manage_deps", label: "Управление подразделениями" },
    { key: "manage_orders", label: "Работа с заявками" },
  ];

  const loadRoles = async () => {
    try {
      const { data } = await api.get("/roles");
      const list = [
        { key: "admin", name: "Администратор", permissions: data.admin || [] },
        { key: "engineer", name: "Инженер", permissions: data.engineer || [] },
        { key: "viewer", name: "Просмотр", permissions: data.viewer || [] },
      ];
      setRoles(list);
    } catch {
      message.error("Ошибка загрузки ролей");
    }
  };

  useEffect(() => {
    loadRoles();
  }, []);

  const togglePermission = async (roleKey, perm) => {
    const role = roles.find((r) => r.key === roleKey);
    if (!role) return;

    const newPerms = role.permissions.includes(perm)
      ? role.permissions.filter((p) => p !== perm)
      : [...role.permissions, perm];

    try {
      await api.put(`/roles/${roleKey}`, { permissions: newPerms });
      setRoles((prev) =>
        prev.map((r) =>
          r.key === roleKey ? { ...r, permissions: newPerms } : r
        )
      );
      message.success("Права обновлены");
    } catch {
      message.error("Ошибка при обновлении прав");
    }
  };

  return (
    <Table
      rowKey="key"
      dataSource={roles}
      pagination={false}
      columns={[
        { title: "Роль", dataIndex: "name" },
        {
          title: "Права",
          render: (_, rec) => (
            <Space direction="vertical">
              {allPermissions.map((p) => (
                <Checkbox
                  key={p.key}
                  checked={rec.permissions.includes(p.key)}
                  onChange={() => togglePermission(rec.key, p.key)}
                >
                  {p.label}
                </Checkbox>
              ))}
            </Space>
          ),
        },
      ]}
    />
  );
}
