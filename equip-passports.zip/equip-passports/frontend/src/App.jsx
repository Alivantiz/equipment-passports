import { useEffect, useState, useMemo } from "react";
import { Routes, Route, useNavigate, useLocation, Navigate } from "react-router-dom";
import { Layout, Menu, notification } from "antd";
import {
  DashboardOutlined,
  DatabaseOutlined,
  FileTextOutlined,
  UserOutlined,
  LogoutOutlined,
  SettingOutlined,
} from "@ant-design/icons";
import { io } from "socket.io-client";

import ProtectedRoute from "./components/ProtectedRoute.jsx";
import AdminRoute from "./components/AdminRoute.jsx";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Catalog from "./pages/Catalog/Catalog.jsx";
import Workorders from "./pages/Workorders/Workorders.jsx";
import Profile from "./pages/Profile.jsx";
import Settings from "./pages/settings";
import api from "./api";

const { Header, Sider, Content } = Layout;

export default function App() {
  const nav = useNavigate();
  const location = useLocation();
  const route = location.pathname;

  const [me, setMe] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("user")) || null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    const token = localStorage.getItem("access");
    if (!token) return;

    const base = (import.meta.env.VITE_API_URL || "http://localhost:8080/api").replace(/\/api\/?$/, "");
    const socket = io(base, { transports: ["websocket"] });

    (async () => {
      try {
        const { data } = await api.get("/users/me");
        setMe(data);
        localStorage.setItem("user", JSON.stringify(data)); // кешируем профиль

        socket.emit("joinUser", data.id);
        if (data.role === "admin") socket.emit("joinAdmin");
        if (data?.department?.id) socket.emit("joinDepartment", data.department.id);
      } catch {
        /* ignore */
      }
    })();

    socket.on("newWorkOrder", (order) => {
      notification.info({
        message: "Новая заявка",
        description: order?.issue || "Создана новая заявка",
        placement: "bottomRight",
      });
    });

    socket.on("statusChanged", (order) => {
      notification.success({
        message: `Заявка №${order?.id}`,
        description: `Статус изменён: ${order?.status}`,
        placement: "bottomRight",
      });
    });

    return () => socket.disconnect();
  }, []);

  const logout = () => {
    const refresh = localStorage.getItem("refresh");
    api.post("/auth/logout", { refresh }).catch(() => {});
    localStorage.clear();
    setMe(null);
    nav("/login");
  };

  // 📌 теперь меню пересобирается при изменении me
  const topItems = useMemo(
    () => [
      { key: "/", icon: <DashboardOutlined />, label: "Дашборд" },
      { key: "/catalog", icon: <DatabaseOutlined />, label: "Каталог" },
      { key: "/workorders", icon: <FileTextOutlined />, label: "Заявки" },
      { key: "/profile", icon: <UserOutlined />, label: "Профиль" },
      ...(me?.role === "admin"
        ? [{ key: "/settings", icon: <SettingOutlined />, label: "Настройки" }]
        : []),
    ],
    [me]
  );

  const bottomItems = [
    {
      key: "__logout__",
      icon: <LogoutOutlined style={{ color: "red" }} />,
      label: <span style={{ color: "red" }}>Выйти</span>,
      onClick: logout,
    },
  ];

  const handleMenuClick = ({ key, item }) => {
    if (key === "__logout__") {
      item?.props?.onClick?.();
      return;
    }
    if (key !== route) nav(key);
  };

  return (
    <Layout style={{ minHeight: "100vh" }}>
      {route !== "/login" && (
        <Sider theme="dark" width={220} style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ color: "white", padding: 16, fontWeight: 600 }}>Южный Инкай</div>

          <Menu
            theme="dark"
            mode="inline"
            selectedKeys={[route]}
            items={topItems}
            onClick={handleMenuClick}
            style={{ flex: 1 }}
          />

          <Menu
            theme="dark"
            mode="inline"
            selectable={false}
            items={bottomItems}
            onClick={handleMenuClick}
            style={{ borderTop: "1px solid rgba(255,255,255,0.12)" }}
          />
        </Sider>
      )}

      <Layout>
        {route !== "/login" && <Header style={{ background: "#fff" }} />}
        <Content style={{ margin: 16 }}>
          <Routes>
            <Route
              path="/login"
              element={
                localStorage.getItem("access") ? (
                  <Navigate to="/" replace />
                ) : (
                  <Login
                    onLogin={(user) => {
                      setMe(user);
                      nav("/");
                    }}
                  />
                )
              }
            />
            <Route element={<ProtectedRoute />}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/catalog" element={<Catalog />} />
              <Route path="/workorders" element={<Workorders />} />
              <Route path="/profile" element={<Profile />} />
              <Route element={<AdminRoute me={me} />}>
                <Route path="/settings" element={<Settings />} />
              </Route>
            </Route>
          </Routes>
        </Content>
      </Layout>
    </Layout>
  );
}
