import axios from 'axios';
const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8080/api' });

let refreshing = null;

api.interceptors.request.use(cfg => {
  const access = localStorage.getItem('access');
  if (access) cfg.headers.Authorization = `Bearer ${access}`;
  return cfg;
});

api.interceptors.response.use(
  r => r,
  async err => {
    if (err.response?.status === 401 && !err.config.__retry) {
      err.config.__retry = true;
      if (!refreshing) {
        refreshing = (async () => {
          const refresh = localStorage.getItem('refresh');
          if (!refresh) throw err;
          const { data } = await axios.post((import.meta.env.VITE_API_URL || 'http://localhost:8080/api') + '/auth/refresh', { refresh });
          localStorage.setItem('access', data.access);
          return data.access;
        })().finally(() => refreshing = null);
      }
      const token = await refreshing;
      err.config.headers.Authorization = `Bearer ${token}`;
      return api(err.config);
    }
    throw err;
  }
);

export default api;
