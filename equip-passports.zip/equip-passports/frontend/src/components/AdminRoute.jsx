import { Navigate, Outlet } from "react-router-dom";

export default function AdminRoute({ me }) {
  if (!me) return null; // пока грузим пользователя
  return me.role === "admin" ? <Outlet /> : <Navigate to="/" replace />;
}
